<?php 
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/getpresident', function (Request $request, Response $response, array $args) {
    
    $sql = "select * from president";
    try {
        $db = new db();
        $db = $db->connect();
        $result = $db->query($sql);
        $president = $result->fetchAll(PDO::FETCH_OBJ);
        return $response->withJson($president);
    }catch(PDOException $e){
        echo $e->getMessage();
    }

});