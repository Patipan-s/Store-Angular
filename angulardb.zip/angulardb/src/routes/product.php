<?php 
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app->get('/getproduct', function (Request $request, Response $response, array $args) {
    
    $sql = "SELECT * FROM `product`";
    try {
        $db = new db();
        $db = $db->connect();
        $result = $db->query($sql);
        $product = $result->fetchAll(PDO::FETCH_OBJ);
        return $response->withJson($product, 200, JSON_NUMERIC_CHECK);
    }catch(PDOException $e){
        echo $e->getMessage();
    }

});